import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final store = AppStore();
  await store.load();
  runApp(DarsyarApp(store: store));
}

class StudySubject {
  String id, name, color;
  int minutes;
  StudySubject({required this.id, required this.name, this.color='آبی', this.minutes=120});
  Map<String,dynamic> toJson()=>{'id':id,'name':name,'color':color,'minutes':minutes};
  factory StudySubject.fromJson(Map<String,dynamic> j)=>StudySubject(
    id:j['id'], name:j['name'], color:j['color']??'آبی', minutes:j['minutes']??120);
}

class StudySession {
  String id, subjectId, title, date;
  int startMinute, duration;
  bool done;
  StudySession({required this.id, required this.subjectId, required this.title,
    required this.date, required this.startMinute, required this.duration, this.done=false});
  Map<String,dynamic> toJson()=>{'id':id,'subjectId':subjectId,'title':title,'date':date,
    'startMinute':startMinute,'duration':duration,'done':done};
  factory StudySession.fromJson(Map<String,dynamic> j)=>StudySession(
    id:j['id'],subjectId:j['subjectId'],title:j['title'],date:j['date'],
    startMinute:j['startMinute'],duration:j['duration'],done:j['done']??false);
}

class Exam {
  String id, subjectId, title, date;
  Exam({required this.id,required this.subjectId,required this.title,required this.date});
  Map<String,dynamic> toJson()=>{'id':id,'subjectId':subjectId,'title':title,'date':date};
  factory Exam.fromJson(Map<String,dynamic> j)=>Exam(
    id:j['id'],subjectId:j['subjectId'],title:j['title'],date:j['date']);
}

class AppStore extends ChangeNotifier {
  List<StudySubject> subjects=[];
  List<StudySession> sessions=[];
  List<Exam> exams=[];
  String goal='ساختن یک برنامه منظم و قابل اجرا';
  String openAiKey='';
  late SharedPreferences _prefs;

  Future<void> load() async {
    _prefs=await SharedPreferences.getInstance();
    subjects=(jsonDecode(_prefs.getString('subjects')??'[]') as List)
      .map((e)=>StudySubject.fromJson(e)).toList();
    sessions=(jsonDecode(_prefs.getString('sessions')??'[]') as List)
      .map((e)=>StudySession.fromJson(e)).toList();
    exams=(jsonDecode(_prefs.getString('exams')??'[]') as List)
      .map((e)=>Exam.fromJson(e)).toList();
    goal=_prefs.getString('goal')??goal;
    openAiKey=_prefs.getString('openai_key')??'';
    if(subjects.isEmpty){
      subjects=[
        StudySubject(id:'math',name:'ریاضی',minutes:180),
        StudySubject(id:'biology',name:'زیست',minutes:150),
        StudySubject(id:'english',name:'انگلیسی',minutes:90),
      ];
      _seedSchedule();
      await save();
    }
  }

  void _seedSchedule(){
    final now=DateTime.now();
    for(int i=0;i<3;i++){
      final d=now.add(Duration(days:i));
      sessions.add(StudySession(id:'s$i',subjectId:subjects[i%subjects.length].id,
        title:'مطالعه و مرور',date:key(d),startMinute:16*60,duration:45));
    }
  }

  String key(DateTime d)=>'${d.year}-${d.month.toString().padLeft(2,'0')}-${d.day.toString().padLeft(2,'0')}';

  Future<void> save() async {
    await _prefs.setString('subjects',jsonEncode(subjects.map((e)=>e.toJson()).toList()));
    await _prefs.setString('sessions',jsonEncode(sessions.map((e)=>e.toJson()).toList()));
    await _prefs.setString('exams',jsonEncode(exams.map((e)=>e.toJson()).toList()));
    await _prefs.setString('goal',goal);
    await _prefs.setString('openai_key',openAiKey);
    notifyListeners();
  }

  StudySubject? subject(String id)=>subjects.where((s)=>s.id==id).cast<StudySubject?>().firstOrNull;
  List<StudySession> forDay(DateTime d)=>sessions.where((s)=>s.date==key(d)).toList()..sort((a,b)=>a.startMinute.compareTo(b.startMinute));

  Future<void> addSubject(String name,int minutes) async {
    subjects.add(StudySubject(id:DateTime.now().microsecondsSinceEpoch.toString(),name:name,minutes:minutes));
    await save();
  }
  Future<void> deleteSubject(String id) async {
    subjects.removeWhere((s)=>s.id==id);
    sessions.removeWhere((s)=>s.subjectId==id);
    exams.removeWhere((e)=>e.subjectId==id);
    await save();
  }
  Future<void> toggle(String id) async {
    final s=sessions.firstWhere((x)=>x.id==id); s.done=!s.done; await save();
  }
  Future<void> addExam(String subjectId,String title,DateTime date) async {
    exams.add(Exam(id:DateTime.now().microsecondsSinceEpoch.toString(),subjectId:subjectId,title:title,date:key(date)));
    await save();
  }
  Future<void> generatePlan({int days=7}) async {
    sessions.removeWhere((s)=>DateTime.parse(s.date).isAfter(DateTime.now().subtract(const Duration(days:1))));
    final now=DateTime.now();
    int slot=16*60;
    int idx=0;
    for(int day=0;day<days;day++){
      final d=DateTime(now.year,now.month,now.day).add(Duration(days:day));
      for(int n=0;n<3 && subjects.isNotEmpty;n++){
        final sub=subjects[(idx++)%subjects.length];
        sessions.add(StudySession(
          id:'${DateTime.now().microsecondsSinceEpoch}_${day}_$n',
          subjectId:sub.id,title:'مطالعه + مرور',date:key(d),
          startMinute:slot,duration:day==0?45:50));
        slot+=70;
        if(slot>20*60){slot=16*60;}
      }
    }
    await save();
  }
  Future<void> moveUndoneToTomorrow() async {
    final today=key(DateTime.now());
    final tomorrow=DateTime.now().add(const Duration(days:1));
    for(final s in sessions.where((x)=>x.date==today && !x.done).toList()){
      s.date=key(tomorrow);
      s.startMinute=16*60 + (sessions.where((x)=>x.date==key(tomorrow)).length*60);
    }
    await save();
  }
}

extension FirstOrNull<E> on Iterable<E> {
  E? get firstOrNull => isEmpty ? null : first;
}


class AiService {
  static Future<String> ask({required String apiKey, required String userText,
      required String context}) async {
    if(apiKey.trim().isEmpty) {
      return 'برای فعال شدن هوش مصنوعی آنلاین، کلید API را در پروفایل وارد کن. فعلاً می‌توانم با برنامه‌ریز داخلی کار کنم.';
    }
    final uri=Uri.parse('https://api.openai.com/v1/responses');
    final body=jsonEncode({
      'model':'gpt-5.6-luna',
      'input':[
        {'role':'system','content':[
          {'type':'input_text','text':
            'تو دستیار برنامه‌ریزی تحصیلی اپلیکیشن درس‌یار هستی. '
            'پاسخ فارسی، کوتاه و عملی بده. اطلاعات برنامه کاربر را تحلیل کن. '
            'اگر کاربر خواست برنامه بسازی، پیشنهاد زمان‌بندی مشخص بده. '
            'هیچ اطلاعاتی را بدون درخواست کاربر حذف نکن.\n\nوضعیت برنامه:\n$context'}
        ]},
        {'role':'user','content':[{'type':'input_text','text':userText}]}
      ],
      'max_output_tokens':800
    });
    try {
      final r=await http.post(uri,headers:{
        'Content-Type':'application/json',
        'Authorization':'Bearer ${apiKey.trim()}'
      },body:body).timeout(const Duration(seconds:30));
      if(r.statusCode<200 || r.statusCode>=300) {
        return 'اتصال به هوش مصنوعی برقرار نشد (${r.statusCode}). کلید API و اتصال اینترنت را بررسی کن.';
      }
      final j=jsonDecode(r.body);
      final out=j['output'];
      if(out is List){
        for(final item in out){
          final content=item['content'];
          if(content is List){
            for(final c in content){
              if(c is Map && c['text'] is String) return c['text'];
            }
          }
        }
      }
      return 'پاسخی از هوش مصنوعی دریافت نشد.';
    } catch(e) {
      return 'خطا در اتصال به هوش مصنوعی. اینترنت را بررسی کن.';
    }
  }
}

class DarsyarApp extends StatelessWidget {
  final AppStore store;
  const DarsyarApp({super.key,required this.store});
  @override Widget build(BuildContext context)=>MaterialApp(
    debugShowCheckedModeBanner:false,title:'درس‌یار',
    theme:ThemeData(useMaterial3:true,colorScheme:ColorScheme.fromSeed(seedColor:const Color(0xFF5B5FEF)),
      fontFamily:'sans'),
    home:MainShell(store:store));
}

class MainShell extends StatefulWidget {
  final AppStore store;
  const MainShell({super.key,required this.store});
  @override State<MainShell> createState()=>_MainShellState();
}
class _MainShellState extends State<MainShell>{
  int index=0;
  @override Widget build(BuildContext context){
    final pages=[HomeTab(store:widget.store),ScheduleTab(store:widget.store),
      SubjectsTab(store:widget.store),ProfileTab(store:widget.store)];
    return AnimatedBuilder(animation:widget.store,builder:(_,__)=>Scaffold(
      body:SafeArea(child:pages[index]),
      bottomNavigationBar:NavigationBar(selectedIndex:index,onDestinationSelected:(i)=>setState(()=>index=i),
        destinations:const[
          NavigationDestination(icon:Icon(Icons.home_outlined),selectedIcon:Icon(Icons.home),label:'خانه'),
          NavigationDestination(icon:Icon(Icons.calendar_month_outlined),selectedIcon:Icon(Icons.calendar_month),label:'برنامه'),
          NavigationDestination(icon:Icon(Icons.menu_book_outlined),selectedIcon:Icon(Icons.menu_book),label:'درس‌ها'),
          NavigationDestination(icon:Icon(Icons.person_outline),selectedIcon:Icon(Icons.person),label:'پروفایل')]))));
  }
}

String faDate(DateTime d)=>'${d.day}/${d.month}/${d.year}';
String timeText(int m)=>'${(m~/60).toString().padLeft(2,'0')}:${(m%60).toString().padLeft(2,'0')}';

class HomeTab extends StatelessWidget{
  final AppStore store; const HomeTab({super.key,required this.store});
  @override Widget build(BuildContext context){
    final today=store.forDay(DateTime.now());
    final done=today.where((x)=>x.done).length;
    return ListView(padding:const EdgeInsets.all(20),children:[
      const Text('سلام 👋',style:TextStyle(fontSize:28,fontWeight:FontWeight.bold)),
      const SizedBox(height:4),Text('برنامه امروزت اینجاست.',style:TextStyle(color:Colors.grey)),
      const SizedBox(height:20),
      Card(elevation:0,child:Padding(padding:const EdgeInsets.all(18),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        const Text('امروز',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
        const SizedBox(height:8),Text('${today.fold<int>(0,(a,b)=>a+b.duration)} دقیقه مطالعه'),
        const SizedBox(height:14),LinearProgressIndicator(value:today.isEmpty?0:done/today.length,minHeight:8),
        const SizedBox(height:8),Text('$done از ${today.length} جلسه انجام شده'),
      ]))),
      const SizedBox(height:16),
      ...today.map((s)=>SessionTile(store:store,session:s)),
      const SizedBox(height:10),
      Card(color:Theme.of(context).colorScheme.primaryContainer,elevation:0,
        child:InkWell(onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>AiChatPage(store:store))),
          borderRadius:BorderRadius.circular(16),child:const Padding(padding:EdgeInsets.all(20),child:Row(children:[
            CircleAvatar(child:Icon(Icons.auto_awesome)),SizedBox(width:14),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
              Text('برای برنامه‌ای پویا‌تر ✨',style:TextStyle(fontWeight:FontWeight.bold,fontSize:17)),
              SizedBox(height:5),Text('هدفت را بگو تا برنامه‌ات را بسازیم یا تغییر دهیم.')
            ])),Icon(Icons.chevron_right)])))),
    ]);
  }
}

class SessionTile extends StatelessWidget{
  final AppStore store; final StudySession session;
  const SessionTile({super.key,required this.store,required this.session});
  @override Widget build(BuildContext context){
    final sub=store.subject(session.subjectId);
    return Card(elevation:0,margin:const EdgeInsets.only(bottom:8),child:ListTile(
      leading:CircleAvatar(child:Text(timeText(session.startMinute).substring(0,2))),
      title:Text('${sub?.name??'درس'} — ${session.title}',style:const TextStyle(fontWeight:FontWeight.w600)),
      subtitle:Text('${timeText(session.startMinute)} • ${session.duration} دقیقه'),
      trailing:Checkbox(value:session.done,onChanged:(_)=>store.toggle(session.id))));
  }
}

class ScheduleTab extends StatelessWidget{
  final AppStore store; const ScheduleTab({super.key,required this.store});
  @override Widget build(BuildContext context){
    final now=DateTime.now();
    return ListView(padding:const EdgeInsets.all(20),children:[
      Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[
        const Text('برنامه هفتگی',style:TextStyle(fontSize:25,fontWeight:FontWeight.bold)),
        FilledButton.icon(onPressed:()=>store.generatePlan(),icon:const Icon(Icons.auto_awesome),label:const Text('ساخت برنامه'))]),
      const SizedBox(height:16),
      for(int i=0;i<7;i++)...[
        Text(faDate(now.add(Duration(days:i))),style:const TextStyle(fontWeight:FontWeight.bold)),
        const SizedBox(height:6),
        ...store.forDay(now.add(Duration(days:i))).map((s)=>SessionTile(store:store,session:s)),
        const SizedBox(height:12),
      ]
    ]);
  }
}

class SubjectsTab extends StatefulWidget{
  final AppStore store; const SubjectsTab({super.key,required this.store});
  @override State<SubjectsTab> createState()=>_SubjectsTabState();
}
class _SubjectsTabState extends State<SubjectsTab>{
  Future<void> add() async {
    final c=TextEditingController(); int mins=120;
    await showDialog(context:context,builder:(_)=>AlertDialog(title:const Text('افزودن درس'),
      content:Column(mainAxisSize:MainAxisSize.min,children:[
        TextField(controller:c,decoration:const InputDecoration(labelText:'نام درس')),
        const SizedBox(height:10),Text('زمان مطالعه هفتگی: $mins دقیقه'),
      ]),actions:[
        TextButton(onPressed:()=>Navigator.pop(context),child:const Text('لغو')),
        FilledButton(onPressed:(){if(c.text.trim().isNotEmpty)widget.store.addSubject(c.text.trim(),mins);Navigator.pop(context);},child:const Text('افزودن'))
      ]));
  }
  @override Widget build(BuildContext context)=>Scaffold(
    backgroundColor:Colors.transparent,body:ListView(padding:const EdgeInsets.all(20),children:[
      Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[
        const Text('درس‌ها',style:TextStyle(fontSize:25,fontWeight:FontWeight.bold)),
        IconButton.filled(onPressed:add,icon:const Icon(Icons.add))]),
      const SizedBox(height:10),
      ...widget.store.subjects.map((s)=>Card(elevation:0,child:ListTile(
        leading:const CircleAvatar(child:Icon(Icons.menu_book)),title:Text(s.name),
        subtitle:Text('${s.minutes} دقیقه در هفته'),
        trailing:IconButton(icon:const Icon(Icons.delete_outline),onPressed:()=>widget.store.deleteSubject(s.id)))))
    ]));
}

class ProfileTab extends StatelessWidget{
  final AppStore store; const ProfileTab({super.key,required this.store});
  @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(20),children:[
    const Text('پروفایل و هدف',style:TextStyle(fontSize:25,fontWeight:FontWeight.bold)),
    const SizedBox(height:16),
    Card(elevation:0,child:Padding(padding:const EdgeInsets.all(18),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      const Text('هدف فعلی',style:TextStyle(fontWeight:FontWeight.bold)),
      const SizedBox(height:8),Text(store.goal),
      const SizedBox(height:14),FilledButton.icon(onPressed:()async{
        final c=TextEditingController(text:store.goal);
        await showDialog(context:context,builder:(_)=>AlertDialog(title:const Text('ویرایش هدف'),
          content:TextField(controller:c,maxLines:3),actions:[
            TextButton(onPressed:()=>Navigator.pop(context),child:const Text('لغو')),
            FilledButton(onPressed:(){store.goal=c.text.trim();store.save();Navigator.pop(context);},child:const Text('ذخیره'))]));
      },icon:const Icon(Icons.edit),label:const Text('ویرایش هدف'))
    ]))),
    const SizedBox(height:12),
    Card(elevation:0,child:ListTile(
      leading:const Icon(Icons.auto_awesome),
      title:const Text('هوش مصنوعی آنلاین'),
      subtitle:Text(store.openAiKey.isEmpty ? 'کلید API ثبت نشده' : 'کلید API ثبت شده'),
      trailing:const Icon(Icons.chevron_right),
      onTap:() async {
        final c=TextEditingController(text:store.openAiKey);
        await showDialog(context:context,builder:(_)=>AlertDialog(
          title:const Text('کلید API هوش مصنوعی'),
          content:TextField(controller:c,obscureText:true,maxLines:1,
            decoration:const InputDecoration(hintText:'sk-...',labelText:'API Key')),
          actions:[
            TextButton(onPressed:()=>Navigator.pop(context),child:const Text('لغو')),
            FilledButton(onPressed:(){store.openAiKey=c.text.trim();store.save();Navigator.pop(context);},
              child:const Text('ذخیره'))
          ]));
      })),
    const SizedBox(height:12),
    Card(elevation:0,child:Column(children:[
      ListTile(leading:const Icon(Icons.refresh),title:const Text('انتقال جلسات انجام‌نشده به فردا'),
        onTap:()=>store.moveUndoneToTomorrow()),
      const Divider(height:1),
      const ListTile(leading:Icon(Icons.lock_outline),title:Text('اطلاعات در خود گوشی ذخیره می‌شود'),
    ]))
  ]);
}

class AiChatPage extends StatefulWidget{
  final AppStore store; const AiChatPage({super.key,required this.store});
  @override State<AiChatPage> createState()=>_AiChatPageState();
}
class _AiChatPageState extends State<AiChatPage>{
  final c=TextEditingController();
  final msgs=<Map<String,String>>[
    {'r':'a','t':'سلام 👋 هدفت، امتحان‌ها، زمان آزادت یا مشکلی که با برنامه داری را بگو. من بر اساس اطلاعات همین برنامه پیشنهاد می‌دهم.'}
  ];
  Future<void> send() async {
    final t=c.text.trim(); if(t.isEmpty)return;
    setState(()=>msgs.add({'r':'u','t':t}));
    c.clear();

    final context = StringBuffer();
    context.writeln('هدف: ${widget.store.goal}');
    context.writeln('درس‌ها: ${widget.store.subjects.map((x)=>'${x.name} (${x.minutes} دقیقه/هفته)').join('، ')}');
    context.writeln('جلسات امروز: ${widget.store.forDay(DateTime.now()).length}');
    context.writeln('امتحان‌ها: ${widget.store.exams.length}');

    if(widget.store.openAiKey.isNotEmpty) {
      setState(()=>msgs.add({'r':'a','t':'در حال بررسی برنامه‌ات...'}));
      final reply=await AiService.ask(apiKey:widget.store.openAiKey,userText:t,context:context.toString());
      if(mounted) setState(() {
        if(msgs.isNotEmpty && msgs.last['t']=='در حال بررسی برنامه‌ات...') msgs.removeLast();
        msgs.add({'r':'a','t':reply});
      });
      return;
    }

    final low=t.toLowerCase();
    if(low.contains('برنامه')||low.contains('بساز')||low.contains('تنظیم')){
      await widget.store.generatePlan();
      if(mounted)setState(()=>msgs.add({'r':'a','t':'برنامه ۷ روز آینده با برنامه‌ریز داخلی ساخته شد. برای هوش مصنوعی آنلاین، کلید API را در پروفایل وارد کن.'}));
    } else if(low.contains('نشد')||low.contains('عقب')||low.contains('امروز')){
      await widget.store.moveUndoneToTomorrow();
      if(mounted)setState(()=>msgs.add({'r':'a','t':'جلسه‌های انجام‌نشده امروز به فردا منتقل شدند.'}));
    } else {
      setState(()=>msgs.add({'r':'a','t':'برای ساخت برنامه بگو «برام برنامه بساز». برای پاسخ‌های هوشمندتر، کلید API را در پروفایل ثبت کن.'}));
    }
  }

  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('برنامه‌ریز هوشمند ✨')),
    body:Column(children:[
      Expanded(child:ListView.builder(padding:const EdgeInsets.all(16),itemCount:msgs.length,itemBuilder:(_,i){
        final user=msgs[i]['r']=='u';
        return Align(alignment:user?Alignment.centerRight:Alignment.centerLeft,child:Container(
          constraints:const BoxConstraints(maxWidth:350),margin:const EdgeInsets.only(bottom:10),
          padding:const EdgeInsets.all(14),decoration:BoxDecoration(
            color:user?Theme.of(context).colorScheme.primaryContainer:Colors.grey.shade200,
            borderRadius:BorderRadius.circular(16)),child:Text(msgs[i]['t']!)));
      })),
      Padding(padding:const EdgeInsets.fromLTRB(12,8,12,12),child:Row(children:[
        Expanded(child:TextField(controller:c,minLines:1,maxLines:4,
          decoration:const InputDecoration(hintText:'مثلاً: برای این هفته برنامه بساز...',border:OutlineInputBorder()),
          onSubmitted:(_)=>send())),
        const SizedBox(width:8),IconButton.filled(onPressed:send,icon:const Icon(Icons.send))
      ]))
    ]));
}
